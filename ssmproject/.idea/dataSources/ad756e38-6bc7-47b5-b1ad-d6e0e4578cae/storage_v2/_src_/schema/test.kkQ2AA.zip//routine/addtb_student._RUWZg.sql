create function addtb_student(b VARCHAR(50)) returns VARCHAR(50)
BEGIN
insert into tb_student(student_name,sex) values(a,b);

END;

