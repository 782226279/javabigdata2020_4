create procedure selUser()
BEGIN
	#Routine body goes here...
select * from user;
END;

