create function insertUser(pwd2 VARCHAR(50)) returns VARCHAR(50)
BEGIN
insert into user(name,pwd) values(name2,pwd2);

END;

