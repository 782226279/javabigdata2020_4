create function selsms() returns INT(10)
BEGIN
	#Routine body goes here...
select * from sms where sms_id=sid;
END;

