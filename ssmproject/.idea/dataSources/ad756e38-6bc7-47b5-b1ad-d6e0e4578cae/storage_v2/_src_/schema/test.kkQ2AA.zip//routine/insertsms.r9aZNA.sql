create function insertsms(bodya VARCHAR(20)) returns VARCHAR(20)
BEGIN
	#Routine body goes here...
insert into sms(sms_tel,sms_body) values(tel,bodya);
END;

