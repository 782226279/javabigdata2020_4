create function seltb_student() returns INT(10)
BEGIN
	select * from tb_student where student_id=kid;
END;

