create function selectUser() returns VARCHAR(50)
BEGIN
select id,name,pwd from user where name like name2;

END;

