create function addUser(b VARCHAR(20)) returns VARCHAR(20)
BEGIN
	#Routine body goes here...
insert into user(name,sex) values(a,b);
END;

