create function addtb_class() returns VARCHAR(50)
BEGIN

insert into tb_class (class_name) values(name);
END;

